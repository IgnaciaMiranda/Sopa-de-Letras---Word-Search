import random
import sys
import os
import tkinter as tk
from tkinter import ttk

# ---------------- RUTA DE RECURSOS (PARA .EXE) ----------------

def recurso_path(rel_path: str) -> str:
    try:
        base_path = sys._MEIPASS  # type: ignore[attr-defined]
    except Exception:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, rel_path)

# ---------------- CARGA DE PALABRAS ----------------

ALFABETO = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
try:
    ruta_listado = recurso_path("listado-general.txt")
    with open(ruta_listado, "r", encoding="utf8") as f:
        TODAS_LAS_PALABRAS = f.read().splitlines()
except FileNotFoundError:
    TODAS_LAS_PALABRAS = [
        "HOLA", "MUNDO", "PYTHON", "JUEGO", "DISENO", "RETRO",
        "FLOR", "LENTES", "GROOVY", "VINTAGE", "RAYO", "CODIGO"
    ]

def palabras_aleatorias(cantidad=4):
    validas = [
        w.strip().upper()
        for w in TODAS_LAS_PALABRAS
        if w.strip().isalpha() and len(w.strip()) > 1
    ]
    validas = list(dict.fromkeys(validas))  # quita duplicados manteniendo orden

    if len(validas) < cantidad:
        print(f"Advertencia: Solo se encontraron {len(validas)} palabras válidas. Se usarán todas.")
        return validas

    return random.sample(validas, cantidad)

# ---------------- LOGICA DE LA SOPA DE LETRAS ----------------

def crear_tablero(tamano):
    return [["" for _ in range(tamano)] for _ in range(tamano)]

def puede_colocar(tablero, palabra, fila, col, dx, dy):
    n = len(tablero)
    for i, letra in enumerate(palabra):
        y, x = fila + dy * i, col + dx * i
        if not (0 <= y < n and 0 <= x < n):
            return False
        if tablero[y][x] not in ("", letra):
            return False
    return True

def colocar_palabra(tablero, palabra):
    n = len(tablero)
    orientaciones = [
        (1, 0), (-1, 0),
        (0, 1), (0, -1),
        (1, 1), (-1, -1),
        (1, -1), (-1, 1)
    ]
    random.shuffle(orientaciones)

    # Mejora: en vez de escoger cualquier inicio, calculamos rangos validos según direccion
    for _ in range(2000):
        dx, dy = random.choice(orientaciones)
        L = len(palabra)

        # rangos de inicio validos para que la palabra caiga dentro del tablero
        min_f = 0 if dy >= 0 else L - 1
        max_f = n - L if dy >= 0 else n - 1
        min_c = 0 if dx >= 0 else L - 1
        max_c = n - L if dx >= 0 else n - 1

        if max_f < min_f or max_c < min_c:
            continue

        fila = random.randint(min_f, max_f)
        col = random.randint(min_c, max_c)

        if puede_colocar(tablero, palabra, fila, col, dx, dy):
            for i, letra in enumerate(palabra):
                tablero[fila + dy * i][col + dx * i] = letra
            return True

    print(f"Advertencia: No se pudo colocar la palabra '{palabra}' en el tablero.")
    return False

def rellenar_vacios(tablero):
    for i in range(len(tablero)):
        for j in range(len(tablero)):
            if tablero[i][j] == "":
                tablero[i][j] = random.choice(ALFABETO)

def generar_sopa(tamano, palabras):
    tablero = crear_tablero(tamano)

    # intentamos colocar todas; si falla mucho, regeneramos (mas robusto)
    for _ in range(5):
        tablero = crear_tablero(tamano)
        ok = True
        for palabra in palabras:
            if not colocar_palabra(tablero, palabra):
                ok = False
                break
        if ok:
            break

    rellenar_vacios(tablero)
    return tablero

# ---------------- PALETA DE COLORES ----------------

COLOR_FONDO = "#00A6A6"
COLOR_ONDA = "#F2E8C9"
COLOR_PANEL = "#F2B705"
COLOR_PANEL_OSCURO = "#D96C00"
COLOR_ROSA = "#F25C78"
COLOR_NARANJA = "#F28705"

COLOR_BOTON_LETRA = "#f0f0f0"
COLOR_BOTON_LETRA_ACTIVA = "#F2B705"
COLOR_BOTON_LETRA_OK = "#b7f7b2"
COLOR_TEXTO_PANEL = "#402E00"


# ---------------- CLASE PRINCIPAL ----------------

class SopaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Sopa con un toque Retro")
        self.centrar_ventana(1280, 720)
        self.root.resizable(False, False)
        self.root.configure(bg=COLOR_FONDO)

        self.configurar_estilos()

        self.tamano = 8
        self.cantidad_palabras = 4
        self.palabras_objetivo = []
        self.tablero = []
        self.botones = []
        self.seleccion_actual = []
        self.encontradas = set()
        self.dificultad_actual = "facil"
        self.frame_inicio = None
        self.frame_juego = None

        self.crear_pantalla_inicio()

    def configurar_estilos(self):
        self.style = ttk.Style()
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass

        self.style.configure("TituloGrande.TLabel", font=("Bauhaus 93", 28), foreground="white", background=COLOR_FONDO)
        self.style.configure("Subtitulo.TLabel", font=("Segoe UI", 11), foreground=COLOR_ONDA, background=COLOR_FONDO)
        self.style.configure("Panel.TFrame", background=COLOR_PANEL, relief="flat")

        self.style.configure("TextoNormal.TLabel", font=("Segoe UI", 11), background=COLOR_PANEL, foreground=COLOR_TEXTO_PANEL)
        self.style.configure("TextoPalabra.TLabel", font=("Segoe UI", 11, "bold"), background=COLOR_PANEL, foreground=COLOR_TEXTO_PANEL)

        # Estilo para palabra encontrada (tachado + rosa)
        self.style.configure(
            "TextoPalabraEncontrada.TLabel",
            font=("Segoe UI", 11, "bold", "overstrike"),
            background=COLOR_PANEL,
            foreground=COLOR_ROSA
        )

        self.style.configure("Estado.TLabel", font=("Segoe UI", 10), background=COLOR_PANEL, foreground="#333")

        # Estilo cuando ganas
        self.style.configure(
            "EstadoGanaste.TLabel",
            font=("Segoe UI", 10, "bold"),
            background=COLOR_PANEL,
            foreground=COLOR_ROSA
        )

        self.style.configure("Retro.TButton", font=("Segoe UI", 11, "bold"), padding=8)
        self.style.map("Retro.TButton",
            background=[('active', COLOR_NARANJA)],
            foreground=[('!active', 'black'), ('active', 'white')]
        )

    def centrar_ventana(self, ancho, alto):
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (ancho // 2)
        y = (self.root.winfo_screenheight() // 2) - (alto // 2)
        self.root.geometry(f"{ancho}x{alto}+{x}+{y}")

    # ---------- INICIO ----------
    def crear_pantalla_inicio(self):
        if self.frame_juego:
            self.frame_juego.destroy()
            self.frame_juego = None

        self.frame_inicio = tk.Frame(self.root, bg=COLOR_FONDO)
        self.frame_inicio.pack(fill="both", expand=True)

        cont_titulo = tk.Frame(self.frame_inicio, bg=COLOR_FONDO)
        cont_titulo.pack(pady=(20, 10))
        ttk.Label(cont_titulo, text="SOPA DE LETRAS by Chibi", style="TituloGrande.TLabel").pack()
        ttk.Label(cont_titulo, text="Edición Groovy", style="Subtitulo.TLabel").pack()

        cont_onda = tk.Frame(self.frame_inicio, bg=COLOR_ONDA)
        cont_onda.pack(fill="both", expand=True, padx=0, pady=(25, 0))

        panel_centro = ttk.Frame(cont_onda, style="Panel.TFrame")
        panel_centro.pack(padx=60, pady=40)
        panel_centro.grid_columnconfigure((0, 1, 2), weight=1)

        ttk.Label(panel_centro, text="Elige tu dificultad", style="TextoNormal.TLabel").grid(
            row=0, column=0, columnspan=3, pady=(15, 15)
        )

        self.crear_tarjeta_dificultad(panel_centro, 0, "Groovy Fácil", "Paz y amor", "flor", "facil")
        self.crear_tarjeta_dificultad(panel_centro, 1, "Retro Medio", "Ponte los lentes", "lentes", "medio")
        self.crear_tarjeta_dificultad(panel_centro, 2, "Vintage Pro", "Desafío eléctrico", "rayo", "avanzado")

        # error correguido tk.Label aqui porque usanba bg/fg directos
        tk.Label(cont_onda, text="Haz clic en una tarjeta para comenzar",
                 bg=COLOR_ONDA, fg="#555", font=("Segoe UI", 10)).pack(pady=(5, 20))

    def crear_tarjeta_dificultad(self, parent, columna, titulo, subtitulo, silueta, dificultad):
        frame = tk.Frame(parent, bg=COLOR_PANEL_OSCURO)
        frame.grid(row=1, column=columna, padx=15, pady=10, ipadx=5, ipady=5, sticky="n")
        tarjeta = tk.Frame(frame, bg=COLOR_PANEL, bd=0)
        tarjeta.pack(padx=6, pady=6)

        canvas = tk.Canvas(tarjeta, width=120, height=120, bg=COLOR_PANEL, highlightthickness=0)
        canvas.pack(pady=(10, 5))

        if silueta == "flor":
            canvas.create_oval(50, 50, 70, 70, fill=COLOR_NARANJA, outline="")
            petalo_color = COLOR_ROSA
            canvas.create_oval(30, 10, 50, 30, fill=petalo_color, outline="")
            canvas.create_oval(70, 10, 90, 30, fill=petalo_color, outline="")
            canvas.create_oval(10, 50, 30, 70, fill=petalo_color, outline="")
            canvas.create_oval(90, 50, 110, 70, fill=petalo_color, outline="")
            canvas.create_oval(30, 90, 50, 110, fill=petalo_color, outline="")
            canvas.create_oval(70, 90, 90, 110, fill=petalo_color, outline="")
        elif silueta == "lentes":
            ancho_lente = 40
            alto_lente = 30
            centro_x1, centro_y = 40, 60
            centro_x2 = 80
            canvas.create_oval(centro_x1 - ancho_lente//2, centro_y - alto_lente//2,
                               centro_x1 + ancho_lente//2, centro_y + alto_lente//2,
                               fill=COLOR_ONDA, outline=COLOR_TEXTO_PANEL, width=3)
            canvas.create_oval(centro_x2 - ancho_lente//2, centro_y - alto_lente//2,
                               centro_x2 + ancho_lente//2, centro_y + alto_lente//2,
                               fill=COLOR_ONDA, outline=COLOR_TEXTO_PANEL, width=3)
            canvas.create_line(centro_x1 + ancho_lente//2, centro_y,
                               centro_x2 - ancho_lente//2, centro_y,
                               fill=COLOR_TEXTO_PANEL, width=3)
            canvas.create_line(centro_x2 + ancho_lente//2, centro_y,
                               centro_x2 + ancho_lente//2 + 20, centro_y - 10,
                               fill=COLOR_TEXTO_PANEL, width=3)
        elif silueta == "rayo":
            puntos = [70, 10, 40, 60, 60, 60, 50, 90, 80, 40, 60, 40, 70, 10]
            canvas.create_polygon(puntos, fill=COLOR_ROSA, outline=COLOR_PANEL_OSCURO, width=4)

        tk.Label(tarjeta, text=titulo, bg=COLOR_PANEL, fg=COLOR_TEXTO_PANEL,
                 font=("Segoe UI", 12, "bold")).pack(pady=(5, 0))
        tk.Label(tarjeta, text=subtitulo, bg=COLOR_PANEL, fg=COLOR_TEXTO_PANEL,
                 font=("Segoe UI", 9)).pack(pady=(0, 10))
        ttk.Button(tarjeta, text="Comenzar", style="Retro.TButton",
                   command=lambda d=dificultad: self.iniciar_juego(d)).pack(pady=(0, 10), fill="x", padx=10)

    def configurar_dificultad(self, dificultad):
        self.dificultad_actual = dificultad
        if dificultad == "facil":
            self.tamano, self.cantidad_palabras = 8, 4
        elif dificultad == "medio":
            self.tamano, self.cantidad_palabras = 10, 6
        else:
            self.tamano, self.cantidad_palabras = 12, 8

    def iniciar_juego(self, dificultad):
        self.configurar_dificultad(dificultad)
        self.crear_pantalla_juego()

    # ---------- JUEGO ----------
    def crear_pantalla_juego(self):
        if self.frame_inicio:
            self.frame_inicio.destroy()
            self.frame_inicio = None

        self.frame_juego = tk.Frame(self.root, bg=COLOR_FONDO)
        self.frame_juego.pack(fill="both", expand=True)

        self.palabras_objetivo = palabras_aleatorias(self.cantidad_palabras)
        self.tablero = generar_sopa(self.tamano, self.palabras_objetivo)

        self.botones, self.seleccion_actual, self.encontradas = [], [], set()

        frame_superior = tk.Frame(self.frame_juego, bg=COLOR_FONDO)
        frame_superior.pack(pady=(15, 10))
        ttk.Label(frame_superior, text="Sopa de Letras by Chibi", style="TituloGrande.TLabel").pack()
        ttk.Label(frame_superior, text=f"Dificultad: {self.dificultad_actual.capitalize()}",
                  style="Subtitulo.TLabel").pack()

        cont_inferior = tk.Frame(self.frame_juego, bg=COLOR_ONDA)
        cont_inferior.pack(expand=True, fill="both", pady=(10, 0))
        cont_inferior.grid_rowconfigure(0, weight=1)
        cont_inferior.grid_columnconfigure(0, weight=1)

        panel = ttk.Frame(cont_inferior, style="Panel.TFrame")
        panel.grid(row=0, column=0)

        frame_sopa = tk.Frame(panel, bg=COLOR_PANEL)
        frame_sopa.grid(row=0, column=0, padx=20, pady=20)

        frame_lateral = tk.Frame(panel, bg=COLOR_PANEL)
        frame_lateral.grid(row=0, column=1, padx=(0, 20), pady=20, sticky="ns")

        fuente_letra = ("Consolas", 14, "bold")
        for i in range(self.tamano):
            fila_botones = []
            for j in range(self.tamano):
                btn = tk.Button(
                    frame_sopa,
                    text=self.tablero[i][j],
                    width=2,
                    height=1,
                    font=fuente_letra,
                    relief="raised",
                    bg=COLOR_BOTON_LETRA,
                    activebackground=COLOR_BOTON_LETRA_ACTIVA,
                    command=lambda f=i, c=j: self.click_celda(f, c)
                )
                btn.grid(row=i, column=j, padx=1, pady=1)
                fila_botones.append(btn)
            self.botones.append(fila_botones)

        tk.Label(frame_lateral, text="Panel de Juego", bg=COLOR_PANEL, fg=COLOR_TEXTO_PANEL,
                 font=("Segoe UI", 12, "bold")).grid(row=0, column=0, sticky="w", pady=(0, 10))

        ttk.Label(frame_lateral, text="Palabras a encontrar:", style="TextoNormal.TLabel").grid(row=1, column=0, sticky="w")

        self.labels_palabras = {}
        for idx, palabra in enumerate(self.palabras_objetivo, start=2):
            lbl = ttk.Label(frame_lateral, text=palabra, style="TextoPalabra.TLabel")
            lbl.grid(row=idx, column=0, sticky="w", pady=2)
            self.labels_palabras[palabra] = lbl

        fila_botones_lateral = len(self.palabras_objetivo) + 3

        self.lbl_progreso = ttk.Label(frame_lateral, text=self.texto_progreso(), style="Estado.TLabel")
        self.lbl_progreso.grid(row=fila_botones_lateral, column=0, sticky="w", pady=(10, 5))

        ttk.Button(frame_lateral, text="Comprobar", style="Retro.TButton", command=self.comprobar_palabra)\
            .grid(row=fila_botones_lateral + 1, column=0, pady=5, sticky="we")
        ttk.Button(frame_lateral, text="Limpiar", style="Retro.TButton", command=self.limpiar_seleccion)\
            .grid(row=fila_botones_lateral + 2, column=0, pady=5, sticky="we")
        ttk.Button(frame_lateral, text="Pista", style="Retro.TButton", command=self.dar_pista)\
            .grid(row=fila_botones_lateral + 3, column=0, pady=5, sticky="we")
        ttk.Button(frame_lateral, text="Nueva Sopa", style="Retro.TButton", command=self.nueva_sopa)\
            .grid(row=fila_botones_lateral + 4, column=0, pady=5, sticky="we")
        ttk.Button(frame_lateral, text="Volver al Inicio", style="Retro.TButton", command=self.crear_pantalla_inicio)\
            .grid(row=fila_botones_lateral + 5, column=0, pady=5, sticky="we")

    def click_celda(self, fila, col):
        coords = (fila, col)

        if coords in self.seleccion_actual:
            if coords == self.seleccion_actual[-1]:
                self.seleccion_actual.pop()
                self.botones[fila][col].config(bg=COLOR_BOTON_LETRA)
            return

        if not self.seleccion_actual:
            self.seleccion_actual.append(coords)
            self.botones[fila][col].config(bg=COLOR_ROSA)
            return

        ultima_fila, ultima_col = self.seleccion_actual[-1]

        if abs(fila - ultima_fila) <= 1 and abs(col - ultima_col) <= 1:
            if len(self.seleccion_actual) > 1:
                penultima_fila, penultima_col = self.seleccion_actual[-2]
                dir_fila = ultima_fila - penultima_fila
                dir_col = ultima_col - penultima_col
                nueva_dir_fila = fila - ultima_fila
                nueva_dir_col = col - ultima_col
                if dir_fila != nueva_dir_fila or dir_col != nueva_dir_col:
                    return

            self.seleccion_actual.append(coords)
            self.botones[fila][col].config(bg=COLOR_ROSA)

    def limpiar_seleccion(self):
        for fila, col in self.seleccion_actual:
            # no “despintar” letras ya encontradas
            if self.botones[fila][col].cget("bg") != COLOR_BOTON_LETRA_OK:
                self.botones[fila][col].config(bg=COLOR_BOTON_LETRA)
        self.seleccion_actual = []

    def comprobar_palabra(self):
        if len(self.seleccion_actual) < 2:
            return

        palabra = "".join(self.tablero[f][c] for f, c in self.seleccion_actual)

        if palabra in self.palabras_objetivo and palabra not in self.encontradas:
            self.marcar_encontrada(palabra)
            self.limpiar_seleccion()
            self.actualizar_progreso()
        elif palabra[::-1] in self.palabras_objetivo and palabra[::-1] not in self.encontradas:
            self.marcar_encontrada(palabra[::-1])
            self.limpiar_seleccion()
            self.actualizar_progreso()
        else:
            self.limpiar_seleccion()

    def marcar_encontrada(self, palabra):
        self.encontradas.add(palabra)

        if palabra in self.labels_palabras:
            #error solucionado, cambia el estilo, no foreground/font directos
            self.labels_palabras[palabra].config(style="TextoPalabraEncontrada.TLabel")

        for fila, col in self.seleccion_actual:
            self.botones[fila][col].config(bg=COLOR_BOTON_LETRA_OK, activebackground=COLOR_BOTON_LETRA_OK)

    def texto_progreso(self):
        return f"Palabras encontradas: {len(self.encontradas)} de {len(self.palabras_objetivo)}"

    def actualizar_progreso(self):
        if len(self.encontradas) == len(self.palabras_objetivo):
            self.lbl_progreso.config(text="¡Felicidades! ¡Has encontrado todas las palabras! Toma una cookie", style="EstadoGanaste.TLabel")
            self.desactivar_botones()
        else:
            self.lbl_progreso.config(text=self.texto_progreso(), style="Estado.TLabel")

    def desactivar_botones(self):
        for fila in self.botones:
            for btn in fila:
                btn.config(state=tk.DISABLED)

    def nueva_sopa(self):
        self.iniciar_juego(self.dificultad_actual)

    def buscar_palabra_en_tablero(self, palabra):
        n = len(self.tablero)
        orientaciones = [
            (1, 0), (-1, 0),
            (0, 1), (0, -1),
            (1, 1), (-1, -1),
            (1, -1), (-1, 1)
        ]

        for fila in range(n):
            for col in range(n):
                for dx, dy in orientaciones:
                    coords = []
                    for i, letra in enumerate(palabra):
                        y = fila + dy * i
                        x = col + dx * i
                        if not (0 <= y < n and 0 <= x < n):
                            break
                        if self.tablero[y][x] != letra:
                            break
                        coords.append((y, x))
                    else:
                        return coords
        return None

    def dar_pista(self):
        pendientes = [p for p in self.palabras_objetivo if p not in self.encontradas]
        if not pendientes:
            return

        palabra = random.choice(pendientes)
        coords = self.buscar_palabra_en_tablero(palabra)
        if coords is None:
            coords = self.buscar_palabra_en_tablero(palabra[::-1])
        if coords is None:
            return

        self.encontradas.add(palabra)
        if palabra in self.labels_palabras:
            self.labels_palabras[palabra].config(style="TextoPalabraEncontrada.TLabel")

        for fila, col in coords:
            self.botones[fila][col].config(bg=COLOR_BOTON_LETRA_OK, activebackground=COLOR_BOTON_LETRA_OK)

        self.actualizar_progreso()

def main():
    root = tk.Tk()

    #ICONO DE LA VENTANA
    icon_path = r"C:\Users\ignacia\Downloads\ideas\Sopa de letras\IconoDeAmbos.png"
    root.icon_img = tk.PhotoImage(file=icon_path)  # guardar referencia
    root.iconphoto(True, root.icon_img)

    app = SopaApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()